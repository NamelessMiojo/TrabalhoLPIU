package br.edu.uniacademia.trabalho;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class JurosSimples extends AppCompatActivity {

    EditText txtCapital, txtJuros , txtTempo;
    Intent Resultado, Voltar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juros_simples);

        txtCapital  = findViewById(R.id.txttitulo);
        txtJuros = findViewById(R.id.txtdesconto);
        txtTempo= findViewById(R.id.txtTempo);
        Button calc = findViewById(R.id.calculamento);
        calc.setOnClickListener(calcJS);

        Resultado = new Intent(this, Result.class);

        Button sair = findViewById(R.id.Sair);
        sair.setOnClickListener(retornar);
        Voltar = new Intent(this, FuncOP.class);
    }

    private View.OnClickListener calcJS = new View.OnClickListener() {
        @RequiresApi(api = Build.VERSION_CODES.Q)
        @Override
        public void onClick(View v) {
           if(txtCapital.getText().toString().isEmpty() || txtJuros.getText().toString().isEmpty() || txtTempo.getText().toString().isEmpty()){
               Context context = getApplicationContext();
               Toast toast = Toast.makeText(context, "Informe todos os dados!", Toast.LENGTH_LONG);
               toast.show();

           }else if(Double.parseDouble(txtCapital.getText().toString())<0 ||Double.parseDouble(txtJuros.getText().toString())<0  || Double.parseDouble(txtTempo.getText().toString())<0){
               Context context = getApplicationContext();
               Toast toast = Toast.makeText(context, "Informe dados positivos!", Toast.LENGTH_LONG);
               toast.show();

           }else{
               Bundle dados = new Bundle();
               double capital = Double.parseDouble(txtCapital.getText().toString());
               double juros = Double.parseDouble(txtJuros.getText().toString());
               double tempo = Double.parseDouble(txtTempo.getText().toString());
               double juroscalc = juros/100;
               double montante;
               double JurosF;

               JurosF = capital*(juroscalc)*tempo;
               montante = JurosF+capital;

               dados.putString("resultadoF", "Juros Aplicados = " + String.valueOf(JurosF) + "\nCapital com Juros = " + String.valueOf(montante));


               Resultado.putExtras(dados);
               startActivity(Resultado);
               finish();

           }
        }
    };

    private View.OnClickListener retornar = new View.OnClickListener() {
        @RequiresApi(api = Build.VERSION_CODES.Q)
        @Override
        public void onClick(View v) {
            startActivity(Voltar);
            finish();
        }
    };
}