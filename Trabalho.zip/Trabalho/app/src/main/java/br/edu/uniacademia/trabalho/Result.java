package br.edu.uniacademia.trabalho;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class Result extends AppCompatActivity {

    Intent Voltar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        Button volta = findViewById(R.id.voltar);
        volta.setOnClickListener(retornar);
        Voltar = new Intent(this, FuncOP.class);

        TextView saida = findViewById(R.id.txtSaida);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        saida.setText(bundle.getString("resultadoF"));

        /*ArrayList<String> jurosmes = bundle.getStringArrayList("resultadoF");
        for(String M : jurosmes){
            saida.setText(M);
        }*/


    }

    private View.OnClickListener retornar = new View.OnClickListener() {
        @RequiresApi(api = Build.VERSION_CODES.Q)
        @Override
        public void onClick(View v) {
            startActivity(Voltar);
            finish();
        }
    };
}