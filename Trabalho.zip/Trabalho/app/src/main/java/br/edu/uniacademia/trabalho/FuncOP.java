package br.edu.uniacademia.trabalho;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FuncOP extends AppCompatActivity {

    Intent jSimples, jComposto, dSimples;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_func_o_p);
        Button jurosS = findViewById(R.id.JurosSimples);
        jurosS.setOnClickListener(jsimp);
        jSimples = new Intent(this, JurosSimples.class);

        Button jurosC = findViewById(R.id.JurosComposto);
        jurosC.setOnClickListener(jcomp);
        jComposto = new Intent(this, JurosComposto.class);

        Button descS = findViewById(R.id.DescontoSimples);
        descS.setOnClickListener(dsimp);
        dSimples = new Intent(this, DescontoSimples.class);

    }

    private View.OnClickListener jsimp = new View.OnClickListener() {
        @RequiresApi(api = Build.VERSION_CODES.Q)
        @Override
        public void onClick(View v) {
            startActivity(jSimples);
            finish();
        }
    };

    private View.OnClickListener jcomp = new View.OnClickListener() {
        @RequiresApi(api = Build.VERSION_CODES.Q)
        @Override
        public void onClick(View v) {
            startActivity(jComposto);
            finish();
        }
    };

    private View.OnClickListener dsimp = new View.OnClickListener() {
        @RequiresApi(api = Build.VERSION_CODES.Q)
        @Override
        public void onClick(View v) {
            startActivity(dSimples);
            finish();
        }
    };
}