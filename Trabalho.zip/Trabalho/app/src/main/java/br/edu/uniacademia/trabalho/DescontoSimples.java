package br.edu.uniacademia.trabalho;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class DescontoSimples extends AppCompatActivity {

    EditText txtTitulo, txtDesconto , txtTempo;
    Intent Resultado, Voltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_desconto_simples);

        txtTitulo  = findViewById(R.id.txttitulo);
        txtDesconto = findViewById(R.id.txtdesconto);
        txtTempo= findViewById(R.id.txtTempo);

        Button calculo = findViewById(R.id.calculamento);
        calculo.setOnClickListener(result);
        Resultado = new Intent(this, Result.class);

        Button sair = findViewById(R.id.Sair);
        sair.setOnClickListener(retornar);
        Voltar = new Intent(this, FuncOP.class);

    }

    private View.OnClickListener result = new View.OnClickListener() {
        @RequiresApi(api = Build.VERSION_CODES.Q)
        @Override
        public void onClick(View v) {
            if(txtTitulo.getText().toString().isEmpty() || txtDesconto.getText().toString().isEmpty() || txtTempo.getText().toString().isEmpty()){
                Context context = getApplicationContext();
                Toast toast = Toast.makeText(context, "Informe todos os dados!", Toast.LENGTH_LONG);
                toast.show();

            }else{
                Bundle dados = new Bundle();
                double titulo = Double.parseDouble(txtTitulo.getText().toString());
                double desconto = Double.parseDouble(txtDesconto.getText().toString());
                double tempo = Double.parseDouble(txtTempo.getText().toString());
                double juroscalc = desconto/100;
                double montante;
                double DescontoF;

                DescontoF = titulo*(juroscalc)*tempo;



                dados.putString("resultadoF", "Desconto aplicado = " + String.valueOf(DescontoF));


                Resultado.putExtras(dados);
                startActivity(Resultado);
                finish();

            }
        }
    };

    private View.OnClickListener retornar = new View.OnClickListener() {
        @RequiresApi(api = Build.VERSION_CODES.Q)
        @Override
        public void onClick(View v) {
            startActivity(Voltar);
            finish();
        }
    };
}